=== Gracipe ===
Contributors: eule2000 (Kai Köhn)
Donate link: http://www.gracipe.com/
Tags: recipes, gracipe, cooking, visualization
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A plugin to embed graphical recipes from http://www.gracipe.com into Wordpress.

== Description ==

A plugin to embed graphical recipes from http://www.gracipe.com into Wordpress.
It will also help you to manage / create new Gracipes and embed them directly.

== Installation ==

1. Install the and activate the plugin through the plugin page
1. You will see a Gracipe menu item, that explains the usage
1. New buttons in the Visual / HTML editor will help you to embed Gracipes


== Screenshots ==

1. Gracipe embedded in your Wordpress blog
2. Managing Gracipes in the Wordpress admin menu

== Changelog ==

= 0.5 =
* Refactoring after initial plugin review. 

= 0.4 =
* First stable version.